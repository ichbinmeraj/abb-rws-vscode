# abb-rws-client

A typed TypeScript/Node.js client for **ABB Robot Web Services** - both protocols ABB ships:

- **RWS 1.0** - IRC5 / RobotWare 6.x → `RwsClient`
- **RWS 2.0** - OmniCore / RobotWare 7.x & 8.x → `RwsClient2`

> **Compatibility:** dual-protocol since v0.7.0. Single-line auto-detection via `createClient()` if you don't know which one your controller speaks.

---

## VS Code Extension

Prefer a GUI? The companion VS Code extension gives you live status, motion data, RAPID control, I/O signals, event log, file management, and CFG database editing directly from the sidebar - no code required. Works against both IRC5 and OmniCore.

**[RAPID Live - ABB Robotics for VS Code](https://marketplace.visualstudio.com/items?itemName=merajsafari.abb-rws)**

---

## Features

- **Dual-protocol** - RWS 1.0 (Digest, JSON) and RWS 2.0 (Basic, XHTML;v=2.0)
- **Auto-detection** - `createClient(host)` probes the auth challenge and returns the right client
- **Multi-robot** - `MultiRobotManager` for orchestrating several controllers in one process
- **Controller discovery** - `RobotManager.discoverControllers()` finds every reachable controller: local RobotStudio VCs on their randomly-assigned ports (OS listening-port scan, no port-range cap, ~1.5 s) plus real robots on the standard ports; `discoverControllersMdns()` adds mDNS/Bonjour with RobotWare metadata
- **Connection lifecycle** - `RobotManager` handles port discovery, polling, WebSocket subscriptions with polling fallback, reconnect-on-failure
- **Typed adapter pattern** - `IRWSAdapter` lets you write code that works across both protocols
- **WebSocket subscriptions** for real-time events (panel state, RAPID exec, signals, persvar, elog, jointtarget, …)
- Session cookie management (IRC5: avoids the controller's 70-session pool fill; OmniCore: avoids 503 lockout from session-pool exhaustion)
- Automatic `/logout` on disconnect to release server-side mastership and free the session slot
- Request rate limiting (< 20 req/sec)
- Fully typed public API - every method throws `RwsError` with a typed `code`
- Single dependency: `ws` (only one we don't reimplement)

---

## Installation

```bash
npm install abb-rws-client
```

**Requirements:** Node.js 20+.

---

## Quick Start (auto-detect)

The simplest path: `createClient` probes the controller and returns the right protocol's client.

```ts
import { createClient, RwsClient2 } from 'abb-rws-client';

const client = await createClient({
  host: '192.168.125.1',
  // username/password default to 'Admin' / 'robotics' (built-in admin account, full UAS grants)
});

console.log(`Connected via ${client instanceof RwsClient2 ? 'RWS 2.0' : 'RWS 1.0'}`);

const state = await client.getControllerState();   // 'motoron' | 'motoroff' | …
const mode  = await client.getOperationMode();     // 'AUTO' | 'MANR' | 'MANF'
const joints = await client.getJointPositions();   // { rax_1, …, rax_6 }

await client.disconnect();
```

If you only target one protocol, skip the helper and instantiate the client directly. See [`examples/`](./examples/) for runnable scripts.

---

## Finding controllers

Don't know the host or port? Discovery finds every reachable controller - including RobotStudio virtual controllers, whose RWS ports are randomly reassigned on every restart:

```ts
import { RobotManager } from 'abb-rws-client';

// TCP probe: local VCs (via the OS's listening ports - any port, ~1.5 s)
// plus real robots on the standard service address/ports.
const found = await RobotManager.discoverControllers();
// [{ host: '127.0.0.1', port: 14880, useHttps: false, authType: 'digest' }, ...]
// authType tells you the generation: 'digest' = RWS 1.0, 'basic' = RWS 2.0

// mDNS/Bonjour: controllers announcing on the local network, with metadata.
const announced = await RobotManager.discoverControllersMdns();
// [{ systemName, host, port, rwVersion?, sysGuid?, probableProtocol }, ...]
```

Run both and merge for the widest net (the VS Code extension does exactly that). Then hand any hit to `createClient({ host, port })`.

---

## Choosing a client

| Controller | Protocol | Class | Auth | Default port |
|---|---|---|---|---|
| **IRC5** (RobotWare 6.x) | RWS 1.0 | `RwsClient` | HTTP Digest | 80 (real), 80 / 11811 (VC) |
| **OmniCore** (RobotWare 7.x) | RWS 2.0 | `RwsClient2` | HTTP Basic | 443 (real), 5466 (VC HTTPS) |

The two generations expose one API: `RwsClient2` carries **280+ endpoint methods**, the RWS 1.0 side covers its generation's full advertised surface (verified by `npm run conformance` against live controllers), and the shared cross-protocol contract - **`IRWSAdapter`, ~190 methods** (controller state, RAPID execution, modules, variables, motion, I/O, file service, CFG database, mastership, event log, search, …) - has the same names and signatures on both. The protocol differences (URL shapes, query-action vs path-action forms, response format, mastership-domain naming, `$HOME` vs `HOME`) are handled internally - your code looks the same.

If you need a single typed reference that holds either:

```ts
import { createAdapter, type IRWSAdapter } from 'abb-rws-client';

const adapter: IRWSAdapter = await createAdapter({ host: '192.168.125.1' });
// adapter is RWS1Adapter or RWS2Adapter - both implement IRWSAdapter
```

---

## RWS 1.0 explicit usage

```ts
import { RwsClient, RwsError } from 'abb-rws-client';

const client = new RwsClient({
  host: '192.168.125.1',
  username: 'Admin',
  password: 'robotics',
});

await client.connect();

// Controller state
const state = await client.getControllerState(); // 'motoron' | 'motoroff' | ...
const mode  = await client.getOperationMode();   // 'AUTO' | 'MANR' | 'MANF'

// Motion
const joints    = await client.getJointPositions();    // rax_1..rax_6 in degrees
const tcp       = await client.getCartesianPosition(); // x/y/z mm + quaternion
const tcpConfig = await client.getCartesianFull();     // + j1/j4/j6/jx config flags

// RAPID
await client.startRapid();
await client.stopRapid();
await client.resetRapid(); // PP to Main

// Variables
const val = await client.getRapidVariable('T_ROB1', 'user', 'reg1');
await client.setRapidVariable('T_ROB1', 'user', 'reg1', '42');

// I/O signals
const signals = await client.listAllSignals();
await client.writeSignal('Local', 'DRV_1', 'DO_1', '1');

// Real-time subscriptions
const unsubscribe = await client.subscribe(
  ['execution', 'controllerstate', { type: 'signal', name: 'Local/DRV_1/DI_1' }],
  (event) => console.log(event.resource, '=', event.value),
);
await unsubscribe();

await client.disconnect();
```

---

## RWS 2.0 explicit usage

```ts
import { RwsClient2 } from 'abb-rws-client';

// RWS 2.0 takes a base URL (scheme + host + port).
//   Real OmniCore:  https://<host>:443
//   OmniCore VC:    https://127.0.0.1:5466
const client = new RwsClient2(
  'https://127.0.0.1:5466',
  'Admin',
  'robotics',
);

await client.connect();

// Same method names as RWS 1.0 - only the underlying protocol differs.
console.log('state:', await client.getControllerState());
console.log('joints:', await client.getJointPositions());

// RAPID variable read - RWS 2.0 symbol API uses suffix-style URLs internally
// (`/rw/rapid/symbol/{symburl}/data`); the method shape is the same.
const tool0 = await client.getRapidVariable('T_ROB1', 'BASE', 'tool0');

// WebSocket subscriptions over the `rws_subscription` subprotocol
// (RWS 1.0 uses `robapi2_subscription` - the names are NOT interchangeable:
// RobotWare 7 rejects the 1.0 name with HTTP 400).
const unsubscribe = await client.subscribe(
  ['controllerstate', 'execution'],
  (event) => console.log(event.resource, '=', event.value),
);

await unsubscribe();
await client.disconnect();
```

### Notable RWS 2.0 quirks (handled automatically)

These are documented because they bite anyone who tries to write an RWS 2.0 client from scratch:

- **HTTP Basic auth**, not Digest (RWS 1.0).
- **XHTML responses only** - `Accept: application/json` returns 406. Library uses `Accept: application/xhtml+xml;v=2.0`.
- **Path-based actions** - `/rw/rapid/execution/stop`, not `?action=stop`.
- **Mastership domains collapsed** - both `'rapid'` and `'cfg'` map to `'edit'`. The adapter maps internally so either name works.
- **File service home** is `'HOME'`, not `'$HOME'`.
- **Symbol API path is suffix-style** - `/rw/rapid/symbol/{symburl}/data` (RWS 1.0 puts `/data` at the front).
- **Module unload** is `POST /rw/rapid/tasks/{task}/unloadmod` with body, NOT `DELETE` on the module URL (returns 405).
- **Self-signed TLS** everywhere - controllers ship self-signed certs, so certificate
  verification is off by default. Pass `strictTls: true` (`RobotManagerOptions`) or
  `rejectUnauthorized: true` (`RwsClient2` options) if your plant installed real certs.
- **WebSocket subscription URL** comes from the `Location` header (real hardware) or the XHTML body (VC). Subprotocol: `rws_subscription` (RWS 2.0) / `robapi2_subscription` (RWS 1.0).

---

## Multi-robot orchestration

For applications that talk to several controllers, use `MultiRobotManager`:

```ts
import { MultiRobotManager } from 'abb-rws-client';

const multi = MultiRobotManager.fromConfigs([
  { id: 'cell-A', name: 'Cell A IRB120',  host: '192.168.125.1', port: 80,   useHttps: false, username: 'Admin', password: 'robotics' },
  { id: 'cell-B', name: 'Cell B IRB1200', host: '192.168.125.2', port: 443,  useHttps: true,  username: 'Admin', password: 'robotics' },
], {
  refreshIntervalMs: 1000, // polling cadence (min 200); slow poll scales at 5×
  strictTls: false,        // true = verify controller TLS certificates
});

multi.onError((msg, actions) => {
  console.error(`Robot error: ${msg}`);
  return Promise.resolve(undefined); // headless: just log
});

multi.onDidChange(() => {
  console.log(`active=${multi.activeId} state=${multi.state.ctrlstate}`);
});

for (const { id } of multi.entries) {
  await multi.connectRobot(id);
}
// One robot is "active" at a time (handy for UIs); state for all is polled.
multi.setActive('cell-B');
```

`MultiRobotManager` wraps individual `RobotManager` instances. Each `RobotManager` handles its own:
- Auto port discovery (probes 5466 / 9403 / 443 / 80 / 11811 in that order, plus a wide-scan fallback when none of those answer - RobotStudio assigns random VC ports above 30000)
- Protocol auto-detection (`WWW-Authenticate: Digest` → RWS 1.0; `Basic` → RWS 2.0)
- Hybrid polling cadence: **5× the refresh interval when WebSocket subscriptions are active** (positions only - state-change resources stream over WS); **the plain refresh interval when subscriptions are unavailable** (full state coverage via polling). Default 1 s / 5 s, configurable via `refreshIntervalMs`.
- WebSocket subscriptions on both protocols, with dropped-socket auto-reconnect and automatic degradation to fast polling if the event stream is terminally lost
- Reconnect-on-failure (3-strike, surfaces via `onError` listener)
- Clean `GET /logout` on disconnect - releases server-side mastership and frees the session slot

You can also create a `RobotManager` directly if you only have one robot.

---

## `RobotManager` - higher-level surface

`RobotManager` wraps either client with operational helpers that handle mastership, polling, and protocol differences for you. In addition to delegating every protocol method to the underlying client, it exposes:

- **`getRmmpPrivilege()`**, **`requestRmmp(level)`**, **`pollRmmp()`**, **`cancelRmmp()`** - the full Remote Mastership Privilege lifecycle (request → poll the pending FlexPendant approval → cancel), on both generations. Required on OmniCore in AUTO mode for any modify op.
- **`getMastershipStatus(domain?)`** - read who currently holds rapid/cfg/motion mastership (uid + application name).
- **`setOperationMode('AUTO' | 'MANR' | 'MANF')`** - VC-only switch with auto-routing through MANR for AUTO ↔ MANF (the controller rejects direct transitions). Acquires `edit` mastership for the higher-privilege direction.
- **`setSpeedRatio(0..100)`** - wraps `edit` mastership; uses the live-verified `?action=setspeedratio&speed-ratio=N` form on RWS 2.0 (the bare endpoint returns 400).
- **`createBackup(name)`**, **`restoreBackup(name)`**, **`getBackupStatus()`**, **`listBackups()`** - `/ctrl/backup/...`
- **`callServiceRoutine(task, name, args?)`** - invoke a service routine remotely (calibration, brake check, etc.).
- **`calcJointsFromCartesian(...)`** - inverse kinematics. **`calcCartesianFromJoints(...)`** - forward kinematics.
- **`setActiveTool(mechunit, name)`**, **`setActiveWobj(mechunit, name)`** - switch active persistent tooldata / wobjdata.
- **CFG write** - `setCfgInstance` / `createCfgInstance` / `removeCfgInstance` / `loadCfgFile` / `saveCfgFile`, on **both** protocols (RWS 2.0 uses `instances/create-default` + the bracket value representation; RWS 1.0 uses the `?action=` forms - handled by the adapters). Each acquires the needed mastership for the duration.
- **DIPC** - `listDipcQueues` / `createDipcQueue` / `sendDipcMessage` / `readDipcMessage` / `removeDipcQueue`. Bidirectional messaging between RAPID and external clients.
- **`listFileVolumes()`** - every controller volume (HOME, BACKUP, DATA, ADDINDATA, PRODUCTS, RAMDISK, TEMP).
- **`getModuleSource(task, name)`** - pull a module's RAPID text in one call. Works even when the module has no backing file in `HOME` (loaded from `.pgf`/RobotStudio/pendant): the client saves it to the controller's TEMP volume, reads it, and deletes it.
- **`compressPath(source, dest)`** / **`decompressPath(source, dest)`** - controller-side archive compression, both generations (RWS 1.0 uses the `?action=comp`/`dcomp` query-actions internally).
- **`searchSignals(criteria)`** / **`searchSignalsEx(criteriaSets)`** / **`searchIoDevices(criteria)`** - server-side I/O search on **both** generations: substring name matching, AND-composed criteria, device search by name/lstate/network. No more paging the full signal list client-side.
- **`getModuleText(task, module)`** / **`getModuleTextRange(task, module, …)`** - read a module's source (or a row/col span) straight from the RAPID domain, with the change-count for optimistic concurrency against `setModuleText`/`setModuleTextRange`.
- **`checkMotionChangeCount(count)`**, **`saveEventLogRaw(dest)`**, **`renameFile(path, newName)`**, **`getVirtualTimeTimeslice()`** - motion-config freshness check, raw event-log export, in-place rename, VC timeslice - all on both generations.
- **`validateCfgFile(path, actionType?)`** / **`validateInstanceBeforeDelete(name)`** - dry-run a CFG load / a CFG instance delete on RWS 1.0 before committing (OmniCore uses `validateCfgInstances`).
- **`validateRapidValue(task, value, datatype)`** - pre-flight a literal before writing.
- **`RobotManager.discoverControllers(extraHosts?)`** *(static)* - find every reachable controller: local VCs on any port (OS listening-port scan, complete and ~1.5 s) plus real robots on the standard ports. See [Finding controllers](#finding-controllers).
- **`RobotManager.discoverControllersMdns(opts?)`** *(static)* - find every ABB controller (real or virtual) announcing on the local network via mDNS/Bonjour. Returns system name, host, RWS port, RobotWare version, system GUID, and a `'rws1' | 'rws2'` classification - no port scanning needed.
- **Simulation panel** *(RWS 2.0 virtual controllers only)* - `simEmergencyStop()`, `simResetEmergencyStop()`, `simGeneralStop(engage?)`, `simAutoStop(engage?)`, `simEnableSwitch(on)`, `teleportMechunit(mechunit, joints, extJoints?)`. Drive the E-stop / guard-stop chain and reposition the simulated robot from the API. Throw `RwsError` on real hardware and RW6 (VC-only endpoints).

Every method returns `Promise<...>` and throws `RwsError` on failure.

### Connection quality

`RobotState.quality` reports connection health as
`'live' | 'polling' | 'reconnecting' | 'stale' | 'disconnected'`, with a
human-readable `state.qualityReason`:

- `live` - WebSocket events streaming; polling runs at the slow cadence
- `polling` - no WebSocket (unavailable or terminally lost); fast polling covers all state
- `reconnecting` - a connect attempt is in flight
- `stale` - 1-2 consecutive polls failed; data may be outdated (heals on the next success)
- `disconnected` - not connected (initial, user disconnect, or auto-disconnect after 3 failed polls)

`MultiRobotManager.onRobotChanged(id => ...)` tells fleet consumers WHICH robot
changed, so a dashboard updates one row instead of diffing every robot's state.
The zero-arg `onDidChange` keeps working unchanged.

---

## Logging

The lib ships a no-op logger by default. Hosts (CLIs, services, the VS Code extension) install their own:

```ts
import { setLogger } from 'abb-rws-client';

setLogger({
  info:  (msg) => console.log(`[info]  ${msg}`),
  warn:  (msg) => console.warn(`[warn]  ${msg}`),
  error: (msg, err) => console.error(`[error] ${msg}`, err),
  show:  () => { /* bring log surface to front; no-op for CLIs */ },
});
```

Internal lifecycle events (connect/disconnect, polling cycles, subscription state, error recovery) flow through this.

---

## API Reference

### Constructor

```ts
new RwsClient(options: RwsClientOptions)
```

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `host` | `string` | - | Controller IP or hostname |
| `port` | `number` | `80` | HTTP port |
| `username` | `string` | `'Admin'` | RWS username |
| `password` | `string` | `'robotics'` | RWS password |
| `requestIntervalMs` | `number` | `55` | Min ms between requests (enforces < 20 req/sec) |
| `timeout` | `number` | `5000` | Request timeout in ms |
| `sessionCookie` | `string` | - | Saved cookie to reuse an existing session slot |

---

### Connection

| Method | Returns | Description |
|--------|---------|-------------|
| `connect()` | `void` | Establish session and authenticate |
| `disconnect()` | `void` | Close WebSocket subscriptions and clear session |
| `getSessionCookie()` | `string \| null` | Current session cookie - persist to avoid 70-session limit |

---

### Controller State & Panel

| Method | Returns | Description |
|--------|---------|-------------|
| `getControllerState()` | `ControllerState` | Motor state: motoron / motoroff / guardstop / emergencystop / … |
| `setControllerState(state)` | `void` | Set motor state - requires mastership |
| `getOperationMode()` | `OperationMode` | AUTO / MANR / MANF |
| `acknowledgeOperationMode(mode)` | `void` | Confirm a pending mode switch, RWS 2.0 |
| `lockOperationMode(pin, permanent?)` | `void` | Lock FlexPendant key switch with PIN |
| `unlockOperationMode()` | `void` | Unlock FlexPendant key switch |
| `getSpeedRatio()` | `number` | Speed override 0-100 |
| `setSpeedRatio(ratio)` | `void` | Set speed override - AUTO mode only |
| `getCollisionDetectionState()` | `CollisionDetectionState` | INIT / TRIGGERED / CONFIRMED / TRIGGERED_ACK |
| `restartController(mode?)` | `void` | restart / istart / pstart / bstart |
| `getControllerIdentity()` | `ControllerIdentity` | Name, ID, type, MAC address |
| `getSystemInfo()` | `SystemInfo` | RobotWare version, options, system ID |
| `getControllerClock()` | `ControllerClock` | Current date/time (UTC) |
| `setControllerClock(y,mo,d,h,mi,s)` | `void` | Set controller date/time (UTC) |
| `getRestartCount()` | `number` | Times the controller has restarted, RWS 2.0 |
| `listProgress()` / `getProgress(id)` | - | Track async operations (backup, log dump) |
| `setPanelLanguage(code)` | `void` | Panel language, both generations (field `lang-code`) |
| `setControllerLanguage(lang)` | `void` | Controller language, both generations (field `lang`) |
| `setExternalEmergencyStop(state)` | `void` | Simulated **external** e-stop circuit, RWS 2.0 |
| `getDiagnostics()` | `DiagnosticsInfo` | Saved diagnostics; `empty: true` when none |

Not available on a virtual controller (they answer 403/404 and surface as typed
`RwsError`s): `saveSystemInfo`, `saveDiagnostics`, and the whole `/ctrl/tpu/*`,
`/ctrl/env`, `/ctrl/systems` and `/ctrl/syslog` group. See
`docs/tasks/endpoint-completion.md` for exactly what each controller answered.

> **The rows tagged `RWS 2.0` above are RWS 2.0 only** (e.g. `acknowledgeOperationMode`,
> `getRestartCount`, `setExternalEmergencyStop`). Every one of their paths answers
> 404 on an IRC5, so they are declared optional on `IRWSAdapter` and `RWS1Adapter`
> does not implement them. Through `RobotManager` the behaviour is explicit: reads
> return a neutral value on RobotWare 6, and **writes throw `UNSUPPORTED_OPERATION`**
> rather than quietly doing nothing. Rows tagged **both generations**
> (`setPanelLanguage`, `setControllerLanguage`) are live-verified on RWS 1.0 too and
> work on either controller.

---

### RAPID Execution

| Method | Returns | Description |
|--------|---------|-------------|
| `getRapidExecutionState()` | `ExecutionState` | `'running'` \| `'stopped'` |
| `getRapidExecutionInfo()` | `ExecutionInfo` | State + current cycle mode |
| `getRapidTasks()` | `RapidTask[]` | All tasks with name, type, state, active flag |
| `startRapid()` | `void` | Start execution (AUTO + motors on required) |
| `startProductionEntry()` | `void` | Start from the production entry point |
| `stopRapid()` | `void` | Stop execution |
| `resetRapid()` | `void` | Reset program pointer to Main |
| `setExecutionCycle(cycle)` | `void` | `'once'` \| `'forever'` \| `'asis'` |
| `activateRapidTask(task)` | `void` | Activate a task (multitasking) |
| `deactivateRapidTask(task)` | `void` | Deactivate a task |
| `activateAllRapidTasks()` | `void` | Activate all tasks |
| `deactivateAllRapidTasks()` | `void` | Deactivate all tasks |

---

### RAPID Variables & Symbols

| Method | Returns | Description |
|--------|---------|-------------|
| `getRapidVariable(task, module, symbol)` | `string` | Read variable as RAPID-syntax string |
| `setRapidVariable(task, module, symbol, value)` | `void` | Write variable (RAPID syntax: `'42'`, `'"hello"'`, `'[1,0,0,0]'`) |
| `validateRapidValue(task, value, datatype)` | `boolean` | Validate value against datatype before writing |
| `getRapidSymbolProperties(task, module, symbol)` | `RapidSymbolProperties` | Type, dims, storage class, flags |
| `searchRapidSymbols(params)` | `RapidSymbolInfo[]` | Search by task, type, datatype, or regex |
| `getActiveUiInstruction()` | `UiInstruction \| null` | Detect if RAPID is waiting for operator input |
| `setUiInstructionParam(stackurl, param, value)` | `void` | Respond to a UI instruction (TPReadNum, TPReadFK…) |

---

### RAPID Modules

| Method | Returns | Description |
|--------|---------|-------------|
| `listModules(taskName)` | `string[]` | Names of all loaded modules in a task |
| `loadModule(task, modulePath, replace?)` | `void` | Load module from controller filesystem into task |
| `unloadModule(task, moduleName)` | `void` | Unload module from task (RAPID must be stopped) |
| `saveModule(task, moduleName, filepath)` | `void` | Save a module's source to a controller volume |
| `loadProgram(task, progpath, loadmode?)` | `void` | Load a full RAPID program (.pgf), RWS 2.0 |
| `saveProgram(task, destination)` | `void` | Save the loaded program to disk, RWS 2.0 |

---

### Motion

| Method | Returns | Description |
|--------|---------|-------------|
| `getJointPositions(mechunit?)` | `JointTarget` | rax_1-rax_6 in degrees (default mechunit: ROB_1) |
| `getRobTarget(mechunit?, tool?, wobj?)` | `RobTarget` | TCP x/y/z (mm) + q1-q4 quaternion for a chosen tool/wobj |
| `getCartesianPosition(mechunit?, tool?, wobj?)` | `RobTarget` | RWS 1.0 name for `getRobTarget` |
| `getCartesianFull(mechunit?)` | `CartesianFull` | TCP pose + j1/j4/j6/jx configuration flags |
| `getMotionSupervision(mechunit?)` / `getPathSupervision(mechunit?)` | - | Supervision mode + level, RWS 2.0 |
| `getAxisPose(mechunit, axis)` | `RobTarget` | Pose of one axis, RWS 2.0 |

---

### File System

| Method | Returns | Description |
|--------|---------|-------------|
| `listDirectory(remotePath)` | `FileEntry[]` | Browse a directory (`$HOME`, `$TEMP`, …) |
| `readFile(remotePath)` | `string` | Download file as UTF-8 string |
| `uploadModule(remotePath, content)` | `void` | Upload file content (max 800 MB) |
| `deleteFile(remotePath)` | `void` | Delete file |
| `createDirectory(parentPath, dirName)` | `void` | Create directory |
| `copyFile(sourcePath, destPath)` | `void` | Copy file on controller |
| `renameFile(path, newName)` | `void` | Rename a file in place, both generations |
| `listFileVolumes()` | `string[]` | Controller volumes/devices |

---

### I/O Signals

| Method | Returns | Description |
|--------|---------|-------------|
| `listAllSignals(start?, limit?)` | `Signal[]` | Paginated flat list of all signals |
| `searchSignals(criteria)` | `Signal[]` | Server-side search (name substring, type, device, network), both generations |
| `searchSignalsEx(criteria[])` | `Signal[]` | Two-criteria search, both generations - the second set **narrows** the first |
| `readSignal(network, device, name)` | `Signal` | Read a specific signal by address |
| `getSignalConfig(network, device, name)` | `Record` | Configuration instance of a signal, RWS 2.0 |
| `writeSignal(network, device, name, value)` | `void` | Write DO/AO/GO - value as string: `'1'`, `'0'`, `'3.14'` |
| `listNetworks()` | `IoNetwork[]` | All I/O networks |
| `listDevices(network)` | `IoDevice[]` | Devices on a network |

> Pass `''` for `network` and `device` to use the flat signal path (works by signal name alone).

---

### Event Log

| Method | Returns | Description |
|--------|---------|-------------|
| `getEventLog(domain?, lang?)` | `ElogMessage[]` | Read log messages (domain 0 = main, newest first) |
| `clearEventLog(domain?)` | `void` | Clear messages in one domain |
| `clearAllEventLogs()` | `void` | Clear all domains |
| `saveEventLogRaw(destination)` | `void` | Dump the full log to a file in system-dump format, both generations |
| `getEventLogMessage(domain, seqnum, lang?)` | `ElogMessage \| null` | One message by domain + sequence number |

---

### Mastership

Required before modifying motor state, speed ratio, or certain RAPID operations.

| Method | Returns | Description |
|--------|---------|-------------|
| `requestMastership(domain)` | `void` | Take control - `'cfg'` \| `'motion'` \| `'rapid'` |
| `releaseMastership(domain)` | `void` | Release control - always call in `finally` |

```ts
await client.requestMastership('rapid');
try {
  await client.setControllerState('motoron');
} finally {
  await client.releaseMastership('rapid');
}
```

---

### WebSocket Subscriptions

```ts
const unsubscribe = await client.subscribe(resources, handler);
// ...
await unsubscribe();
```

| Resource | Type | Description |
|----------|------|-------------|
| `'execution'` | string | RAPID execution state changes |
| `'controllerstate'` | string | Motor state changes |
| `'operationmode'` | string | Operation mode changes |
| `'speedratio'` | string | Speed ratio changes |
| `'coldetstate'` | string | Collision detection state |
| `'uiinstr'` | string | Active UI instruction changes |
| `{ type: 'execycle' }` | object | Execution cycle mode changes |
| `{ type: 'taskchange', task }` | object | Task state changes |
| `{ type: 'signal', name }` | object | I/O signal value changes |
| `{ type: 'persvar', name }` | object | RAPID persistent variable changes |
| `{ type: 'elog', domain }` | object | New event log entries |

`SubscriptionEvent`: `{ resource: string, value: string, timestamp: Date }`

The stream self-heals on both protocol generations. Heartbeats detect half-open
connections, drops reconnect with capped exponential backoff (defaults: RWS 1.0
starts at 1 s, RWS 2.0 at 500 ms, both doubling to a 30 s cap over 6 attempts),
and a controller restart triggers a fresh registration - on RWS 1.0 riding the
same session, on RWS 2.0 adopting the fresh session the restart forces. Tune it
or hook the lifecycle via the options:

```ts
// RWS 1.0 (RwsClient): options are the third argument
const unsubscribe = await client.subscribe(resources, handler, {
  onRestored: () => resyncState(),   // reconnected - events may have been missed
  onLost:     () => usePolling(),    // reconnect budget exhausted, stream is gone
  maxReconnectAttempts: 6,
  reconnectBaseMs: 1000,
  reconnectCapMs: 30000,
  pingIntervalMs: 10000,
  openTimeoutMs: 8000,
});

// RWS 2.0 (RwsClient2): callbacks are positional, tuning is the fifth argument
const unsub2 = await client2.subscribe(resources, handler, onLost, onRestored, {
  reconnectBaseMs: 500,
  pingIntervalMs: 25000,
});
```

`RobotManager` wires this automatically: it resyncs with a full poll on restore and
falls back to fast polling on loss.

#### Editing a live group (RWS 2.0)

A subscription group can be changed in place instead of being torn down and
rebuilt. The handle `subscribe()` returns is still just the unsubscribe
function, but it also carries the group's path:

```ts
const unsubscribe = await client2.subscribe(['controllerstate'], handler);

// Add a resource. The PUT response carries its INITIAL value event, so you get
// the starting state without waiting for the first change.
await client2.updateSubscriptionGroup(unsubscribe.groupPath, ['speedratio']);

// Drop just that one resource; the group and its WebSocket stay up.
await client2.unsubscribeResource(unsubscribe.groupPath, 'speedratio');

await unsubscribe();   // tears down the whole group, as before
```

Adding is additive, not a replace. Removing the *last* resource retires the
group, after which the controller rejects further edits - call the unsubscribe
handle when you mean to tear everything down.

`RobotManager` owns its own subscription; edit that one through
`manager.subscriptionGroupPath` (it is `undefined` when the manager is
polling-only or talking to an IRC5):

```ts
const group = manager.subscriptionGroupPath;
if (group) { await manager.updateSubscriptionGroup(group, ['uiinstr']); }
```

---

### Error Handling

All public methods throw `RwsError` - never a plain `Error`.

| Code | Meaning |
|------|---------|
| `'AUTH_FAILED'` | Wrong credentials (auth handshake failed) - never used for permission errors |
| `'MASTERSHIP_REQUIRED'` | Write needs mastership, or another client holds it |
| `'GRANT_DENIED'` | Controller rejected the operation - RMMP not granted or UAS grant missing |
| `'WRONG_MODE'` | Operation not allowed in the current controller state / op-mode |
| `'RESOURCE_NOT_FOUND'` | Signal / file / symbol / path does not exist on the controller |
| `'MODULE_NOT_FOUND'` | RAPID module not loaded on the controller |
| `'SESSION_EXPIRED'` | Session timed out |
| `'MOTORS_OFF'` | Action requires motors on |
| `'CONTROLLER_BUSY'` | Controller returned 503 - retry later |
| `'RATE_LIMITED'` | Too many requests (429) |
| `'NETWORK_ERROR'` | TCP / timeout / WebSocket error |
| `'PARSE_ERROR'` | Unexpected XML response format |
| `'UNSUPPORTED_OPERATION'` | This protocol generation / controller does not have the operation |
| `'INVALID_ARGUMENT'` | Caller passed a value the controller cannot accept - nothing was sent |
| `'NOT_CONNECTED'` | `connect()` has not run (or the manager has no adapter yet) |
| `'PROTOCOL_DETECT_FAILED'` | Could not determine RWS 1.0 vs 2.0 during connect |
| `'UNKNOWN'` | Unmapped error - check `httpStatus` and `rwsDetail` |

4xx responses are classified by the controller's own error body, not the HTTP
status: `RwsError.controllerCode` / `controllerMsg` carry the native status
(e.g. `-1073445862` "held by someone else") and the message says what to do
about it. Every mapping is backed by payloads captured from live controllers
(`tests/fixtures/errors/`).

```ts
try {
  await client.startRapid();
} catch (e) {
  if (e instanceof RwsError) {
    if (e.code === 'MOTORS_OFF') console.error('Enable motors first');
    else throw e;
  }
}
```

---

## Session Persistence

IRC5 controllers allow a maximum of **70 concurrent RWS sessions**; OmniCore controllers also have a finite session pool (the exact number isn't published, but heavy probing without `/logout` returns HTTP 503 once it fills). Persist the session cookie across restarts to always reuse the same slot - the lib calls `/logout` on `disconnect()` to free the slot cleanly, but a saved cookie is the most robust path:

```ts
import fs from 'fs';

// Save after connecting
const cookie = client.getSessionCookie();
if (cookie) fs.writeFileSync('.rws-session', cookie, 'utf8');

// Restore on next start
let sessionCookie: string | undefined;
try { sessionCookie = fs.readFileSync('.rws-session', 'utf8'); } catch {}

const client = new RwsClient({ host, username, password, sessionCookie });
await client.connect(); // reuses the existing session slot
```

---

## Rate Limits

| Constraint | Value | Source |
|------------|-------|--------|
| Max request rate | 20 req/sec | Both protocols (controller-enforced) |
| Client-enforced interval | 55 ms between requests | This package, default |
| Max concurrent sessions | 70 (IRC5) / finite (OmniCore) | Controller-enforced |
| Session inactivity timeout | 5 minutes (IRC5) | Controller-enforced |
| Max session lifetime | 25 minutes (IRC5) | Controller-enforced |
| Max file upload | 800 MB (IRC5) | Controller-enforced; OmniCore is similar |

OmniCore-specific limits aren't fully documented by ABB; what the lib observes empirically matches the IRC5 numbers within an order of magnitude.

---

## Compatibility

| | RobotWare 6.x (RWS 1.0) | RobotWare 7.x (RWS 2.0) | RobotWare 8.x (RWS 2.0) |
|--|--|--|--|
| This package | ✅ `RwsClient` | ✅ `RwsClient2` | ✅ `RwsClient2` |
| IRC5 controller (real) | ✅ | n/a | n/a |
| OmniCore controller (real) | n/a | ✅ | ✅ |
| RobotStudio virtual controller | ✅ (RW6.x VC) | ✅ (RW7.x VC) | ✅ (RW8.x VC) |
| Auto-detect from one entry point | ✅ via `createClient()` | ✅ via `createClient()` | ✅ via `createClient()` |
| Write access | Mastership | Mastership | Control Station (automatic) |

RobotWare 8 removes the mastership service and requires a registered control
station for write access. The client detects the RobotWare version on connect
and routes write access automatically, so the same code runs on all three
generations. The full Control Station Service is also exposed directly
(`requestWriteAccess`, `getWriteAccessStatus`, `setAllowMotionControl`, ...).

**Live-tested matrix**: RobotWare 8.1 (OmniCore VC), RobotWare 7.21 (OmniCore VC), RobotWare 6.16 (IRC5 VC). 630+ unit tests + live protocol-coverage tests + chaos-proxy resilience suites. Endpoint conformance against what the live controllers actually advertise: 59 implemented / 0 unmapped / 0 orphan (`npm run conformance`).

---

## Resources

**What this client is proven to do**

- [COVERAGE.md](./docs/COVERAGE.md) - the guarantees and how each one is tested.
- [STRUCTURAL.md](./STRUCTURAL.md) - what happens when the network, the controller
  or the clock misbehaves: a fault-injection matrix run against live controllers,
  where every cell is `verified`, `manual-only` or `excluded` and never assumed.
  Regenerate with `npm run structural`.
- [CONFORMANCE.md](./CONFORMANCE.md) - does the client cover what the controllers
  actually advertise? Diffs the path tables in `src/paths` against a live crawl of
  each controller's resource tree, flagging any advertised resource nothing maps.
  Regenerate with `npm run conformance`.
- [ARCHITECTURE.md](./docs/ARCHITECTURE.md) - how the pieces fit together.

**Where the URLs live**

Every RWS URL the client uses is declared once in [`src/paths`](./src/paths),
one table per RWS domain, keyed by operation and split by protocol generation.
That is the single source of truth an ABB update lands in - and what
`npm run conformance` checks against the live controllers.

**External**

- [ABB Developer Center - RWS API](https://developercenter.robotstudio.com/api/rwsApi/)
- [RAPID Live - the companion VS Code extension](https://marketplace.visualstudio.com/items?itemName=merajsafari.abb-rws)

---

## License

MIT - see [LICENSE](./LICENSE)
