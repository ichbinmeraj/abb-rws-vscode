/**
 * ResourceMapper - pure functions that map RWS operations to URL paths and
 * application/x-www-form-urlencoded request bodies.
 *
 * No HTTP, no state. All functions are individually exported for tree-shaking.
 * Targets RWS 1.0 (RobotWare 6.x). Not compatible with RWS 2.0 / RobotWare 7.x.
 */

import { RwsError } from './types.js';
import { PANEL } from './paths/panel.js';
import { RAPID } from './paths/rapid.js';
import { MOTION } from './paths/motion.js';
import { IO } from './paths/io.js';
import { CFG_ELOG_DIPC } from './paths/cfgElogDipc.js';
import { CTRL } from './paths/ctrl.js';
import { SYSTEM_MASTERSHIP } from './paths/systemMastership.js';
import { FILES_VISION } from './paths/filesVision.js';
import { buildPath, type PathSpec } from './paths/PathSpec.js';

/**
 * RWS 1.0 path for a panel operation, from the path table (src/paths/panel.ts).
 * The tables are the single source of RWS URLs; this domain reads them rather
 * than repeating the literal. Body-building stays here. buildPath renders the
 * `?action=` query the RWS 1.0 panel writes use. Fidelity is proven by
 * tests/paths.test.ts.
 */
const p1 = (op: keyof typeof PANEL, params?: Record<string, string | number>): string =>
  buildPath(PANEL[op].rws1 as PathSpec, params);

// ─── Controller ──────────────────────────────────────────────────────────────

/** Path to read the current controller state (motoron, motoroff, etc.) */
export function controllerState(): string {
  return p1('getControllerState');
}

/** Path + body to set the controller motor state (motoron / motoroff). Requires mastership. */
export function setControllerState(state: 'motoron' | 'motoroff'): { path: string; body: string } {
  return {
    path: p1('setControllerState'),
    body: `ctrl-state=${state}`,
  };
}

/** Path to read the current operation mode (AUTO, MANR, MANF) */
export function operationMode(): string {
  return p1('getOperationMode');
}

/** Path to read the current speed ratio (0-100) */
export function speedRatio(): string {
  return p1('getSpeedRatio');
}

/**
 * Validate a speed ratio and return it as the integer percent the controller
 * wants. Shared by both protocol builders.
 *
 * This used to clamp with Math.min/Math.max, which meant a caller who passed
 * 500, or 0.85 meaning "85%", silently got a different robot speed than they
 * asked for and no indication anything was wrong. Speed is a motion parameter,
 * so guessing at the caller's intent is the wrong default: reject instead, and
 * reject before anything reaches the controller.
 */
export function assertSpeedRatio(ratio: number): number {
  if (!Number.isFinite(ratio) || ratio < 0 || ratio > 100) {
    throw new RwsError(
      `Speed ratio must be between 0 and 100, got ${ratio}`,
      'INVALID_ARGUMENT',
    );
  }
  return Math.round(ratio);
}

/** Path + body to set the speed ratio. Only valid in AUTO mode. @param ratio 0-100 */
export function setSpeedRatio(ratio: number): { path: string; body: string } {
  return {
    path: p1('setSpeedRatio'),
    body: `speed-ratio=${assertSpeedRatio(ratio)}`,
  };
}

// ─── RAPID ───────────────────────────────────────────────────────────────────

/** Path to list all RAPID tasks */
export function rapidTasks(): string {
  return buildPath(RAPID.getRapidTasks.rws1 as PathSpec);
}

/** Path to read the RAPID execution state (running / stopped) */
export function rapidExecutionState(): string {
  return buildPath(RAPID.getRapidExecutionState.rws1 as PathSpec);
}

/**
 * Path + body to start RAPID program execution.
 *
 * `cycle=asis` keeps the currently configured cycle mode, matching RWS 2.0
 * (ResourceMapper2.startRapid). Hardcoding `cycle=forever` here previously
 * OVERRODE a prior setExecutionCycle('once'), so a program the caller wanted to
 * run once looped continuously. `asis` is documented for both generations, and
 * the controller's default cycle is `forever`, so a caller who never set a cycle
 * sees no change - only an explicit setExecutionCycle is now honoured.
 */
export function startRapid(): { path: string; body: string } {
  return {
    path: buildPath(RAPID.startRapid.rws1 as PathSpec),
    body: 'regain=continue&execmode=continue&cycle=asis&condition=none&stopatbp=disabled&alltaskbytsp=false',
  };
}

/** Path + body to stop RAPID program execution */
export function stopRapid(): { path: string; body: string } {
  return {
    path: buildPath(RAPID.stopRapid.rws1 as PathSpec),
    body: 'stopmode=stop',
  };
}

/**
 * Path + body to reset the RAPID program pointer to main.
 * The body is empty but Content-Type must still be application/x-www-form-urlencoded.
 */
export function resetRapid(): { path: string; body: string } {
  return {
    path: buildPath(RAPID.resetRapid.rws1 as PathSpec),
    body: '',
  };
}

/**
 * Path + body to set the RAPID execution cycle mode.
 * @param cycle - 'once' (run once then stop) | 'forever' (loop indefinitely) | 'asis' (keep current)
 */
export function setExecutionCycle(cycle: 'once' | 'forever' | 'asis'): { path: string; body: string } {
  return {
    path: buildPath(RAPID.setExecutionCycle.rws1 as PathSpec),
    body: `cycle=${cycle}`,
  };
}

// ─── Controller panel ────────────────────────────────────────────────────────

/** Path to read the collision detection state (INIT/TRIGGERED/CONFIRMED/TRIGGERED_ACK). */
export function collisionDetectionState(): string {
  return p1('getCollisionDetectionState');
}

/**
 * Path + body to restart (or shutdown) the controller.
 * @param mode - 'restart' | 'istart' | 'pstart' | 'bstart'
 */
export function restartController(mode: 'restart' | 'istart' | 'pstart' | 'bstart'): { path: string; body: string } {
  return {
    path: p1('restartController'),
    body: `restart-mode=${mode}`,
  };
}

/**
 * Path + body to lock the operation mode selector.
 * @param pin - 4-digit PIN
 * @param permanent - true = permanent lock; false = temporary
 */
export function lockOperationMode(pin: string, permanent: boolean): { path: string; body: string } {
  return {
    path: p1('lockOperationMode'),
    body: `pin=${encodeURIComponent(pin)}&permanent=${permanent ? 1 : 0}`,
  };
}

/** Path + body to unlock the operation mode selector. */
export function unlockOperationMode(): { path: string; body: string } {
  return { path: p1('unlockOperationMode'), body: '' };
}

// ─── RAPID UI instructions ───────────────────────────────────────────────────

/** Path to GET the currently active RAPID UI instruction (if any). */
export function activeUiInstruction(): string {
  return buildPath(RAPID.getActiveUiInstruction.rws1 as PathSpec);
}

/**
 * Path + body to set a parameter value on the active RAPID UI instruction.
 * Used to respond programmatically to TPReadNum, TPReadFK, etc.
 *
 * @param stackurl - Full stack URL from the UiInstruction.stack field (e.g. 'RAPID/T_ROB1/%$104')
 * @param uiparam  - Parameter name: 'Result', 'TPFK1' … 'TPFK5', 'TPCompleted', etc.
 * @param value    - New value (e.g. '42', 'TRUE', '0')
 */
export function setUiInstructionParam(
  stackurl: string, uiparam: string, value: string,
): { path: string; body: string } {
  return {
    path: buildPath(RAPID.setUiInstructionParam.rws1 as PathSpec, { stackurl, uiparam }),
    body: `value=${encodeURIComponent(value)}`,
  };
}

// ─── RAPID task activation ───────────────────────────────────────────────────

/** Path + body to activate a single RAPID task (multitasking). */
export function activateRapidTask(task: string): { path: string; body: string } {
  return { path: buildPath(RAPID.activateRapidTask.rws1 as PathSpec, { task }), body: '' };
}

/** Path + body to deactivate a single RAPID task (multitasking). */
export function deactivateRapidTask(task: string): { path: string; body: string } {
  return { path: buildPath(RAPID.deactivateRapidTask.rws1 as PathSpec, { task }), body: '' };
}

/** Path + body to activate ALL RAPID tasks. */
export function activateAllRapidTasks(): { path: string; body: string } {
  return { path: buildPath(RAPID.activateAllRapidTasks.rws1 as PathSpec), body: '' };
}

/** Path + body to deactivate ALL RAPID tasks. */
export function deactivateAllRapidTasks(): { path: string; body: string } {
  return { path: buildPath(RAPID.deactivateAllRapidTasks.rws1 as PathSpec), body: '' };
}

// ─── RAPID symbol search / validate ─────────────────────────────────────────

/**
 * Path + body to search RAPID symbols across a task.
 * POST /rw/rapid/symbols?action=search-symbol
 */
export function searchRapidSymbols(params: {
  task: string;
  view?: string;
  vartyp?: string;
  symtyp?: string;
  dattyp?: string;
  regexp?: string;
  recursive?: boolean;
  blockurl?: string;
}): { path: string; body: string } {
  const parts: string[] = [];
  parts.push(`task=${encodeURIComponent(params.task)}`);
  if (params.view)      parts.push(`view=${encodeURIComponent(params.view)}`);
  if (params.vartyp)    parts.push(`vartyp=${encodeURIComponent(params.vartyp)}`);
  if (params.symtyp)    parts.push(`symtyp=${encodeURIComponent(params.symtyp)}`);
  if (params.dattyp)    parts.push(`dattyp=${encodeURIComponent(params.dattyp)}`);
  if (params.regexp)    parts.push(`regexp=${encodeURIComponent(params.regexp)}`);
  if (params.blockurl)  parts.push(`blockurl=${encodeURIComponent(params.blockurl)}`);
  if (params.recursive !== undefined) parts.push(`recursive=${params.recursive}`);
  return {
    path: buildPath(RAPID.searchRapidSymbols.rws1 as PathSpec),
    body: parts.join('&'),
  };
}

/**
 * Path + body to validate a value against a RAPID data type.
 * POST /rw/rapid/symbol/data?action=validate
 * Returns 204 if valid, 400 if invalid.
 */
export function validateRapidValue(task: string, value: string, datatype: string): { path: string; body: string } {
  return {
    path: buildPath(RAPID.validateRapidValue.rws1 as PathSpec),
    body: `task=${encodeURIComponent(task)}&value=${encodeURIComponent(value)}&datatype=${encodeURIComponent(datatype)}`,
  };
}

// ─── RAPID symbols ───────────────────────────────────────────────────────────

/**
 * Path to read RAPID symbol properties (type, dimensions, storage, etc.).
 * @param taskName   - RAPID task name, e.g. 'T_ROB1'
 * @param moduleName - Module name, e.g. 'user'
 * @param symbolName - Symbol name, e.g. 'reg1'
 */
export function rapidSymbolProperties(taskName: string, moduleName: string, symbolName: string): string {
  return buildPath(RAPID.getRapidSymbolProperties.rws1 as PathSpec, { task: taskName, module: moduleName, symbol: symbolName });
}

/**
 * Path to read a RAPID symbol value.
 * @param taskName   - RAPID task name, e.g. 'T_ROB1'
 * @param moduleName - Module name, e.g. 'user'
 * @param symbolName - Symbol name, e.g. 'reg1'
 */
export function rapidSymbol(taskName: string, moduleName: string, symbolName: string): string {
  return buildPath(RAPID.getRapidVariable.rws1 as PathSpec, { task: taskName, module: moduleName, symbol: symbolName });
}

/**
 * Path + body to set a RAPID symbol value.
 * @param taskName   - RAPID task name
 * @param moduleName - Module name
 * @param symbolName - Symbol name
 * @param value      - New value as RAPID-formatted string, e.g. '42', '"hello"', '[1,2,3]'
 */
export function setRapidSymbol(
  taskName: string,
  moduleName: string,
  symbolName: string,
  value: string,
): { path: string; body: string } {
  return {
    path: buildPath(RAPID.setRapidVariable.rws1 as PathSpec, { task: taskName, module: moduleName, symbol: symbolName }),
    body: `value=${encodeURIComponent(value)}`,
  };
}

// ─── Motion ──────────────────────────────────────────────────────────────────

/**
 * Path to read joint-space positions for a mechanical unit.
 * @param mechunit - Default 'ROB_1' (the primary robot mechanical unit)
 */
export function jointTarget(mechunit = 'ROB_1'): string {
  return buildPath(MOTION.getJointPositions.rws1 as PathSpec, { mechunit });
}

/**
 * Path to read Cartesian robot target.
 * @param mechunit - Default 'ROB_1'
 * @param tool     - Active tool frame; default 'tool0'
 * @param wobj     - Active work object frame; default 'wobj0'
 */
export function robTarget(mechunit = 'ROB_1', tool = 'tool0', wobj = 'wobj0'): string {
  return `${buildPath(MOTION.getRobTarget.rws1 as PathSpec, { mechunit })}?tool=${encodeURIComponent(tool)}&wobj=${encodeURIComponent(wobj)}`;
}

/**
 * Path to read Cartesian position including robot configuration flags (j1, j4, j6, jx).
 * Uses the /cartesian sub-resource instead of /robtarget - no tool/wobj parameters.
 * @param mechunit - Default 'ROB_1'
 */
export function cartesianFull(mechunit = 'ROB_1'): string {
  return buildPath(MOTION.getCartesianFull.rws1 as PathSpec, { mechunit });
}

// ─── Modules ─────────────────────────────────────────────────────────────────

/**
 * Path + body to load a RAPID module into a task.
 * @param taskName   - RAPID task name, e.g. 'T_ROB1'
 * @param modulePath - Controller filesystem path, e.g. '$HOME/MyMod.mod'
 *                     Do not double-encode the '$' prefix - the controller expects it literal.
 */
export function loadModule(taskName: string, modulePath: string, replace = false): { path: string; body: string } {
  return {
    path: buildPath(RAPID.loadModule.rws1 as PathSpec, { task: taskName }),
    body: `modulepath=${encodeURIComponent(modulePath)}&replace=${replace}`,
  };
}

/**
 * Path to retrieve details about a specific loaded module.
 * @param taskName   - RAPID task name
 * @param moduleName - Module name (without path or extension)
 */
export function getModule(taskName: string, moduleName: string): string {
  return `/rw/rapid/tasks/${encodeURIComponent(taskName)}/modules/${encodeURIComponent(moduleName)}`;
}

/**
 * Path to list all modules loaded in a RAPID task.
 * @param taskName - RAPID task name
 */
export function listModules(taskName: string): string {
  return `${buildPath(RAPID.listModules.rws1 as PathSpec)}?task=${encodeURIComponent(taskName)}`;
}

// ─── File system ─────────────────────────────────────────────────────────────

/**
 * PUT path for uploading a file to the controller filesystem.
 * Use '$HOME/' prefix to target the controller home directory.
 * @param remotePath - Controller path, e.g. '$HOME/MyMod.mod'
 */
export function uploadFile(remotePath: string): string {
  return fileServicePath(remotePath);
}

// ─── Controller info ─────────────────────────────────────────────────────────

/** Path to get RobotWare system information (version, options, sysid) */
export function systemInfo(): string {
  return buildPath(SYSTEM_MASTERSHIP.getSystemInfo.rws1 as PathSpec);
}

/** Path to get controller hardware identity (name, id, type, mac) */
export function controllerIdentity(): string {
  return buildPath(CTRL.getControllerIdentity.rws1 as PathSpec);
}

/** Path to GET the controller clock datetime. */
export function clockInfo(): string {
  return buildPath(CTRL.getControllerClock.rws1 as PathSpec);
}

/**
 * Path + body to SET the controller clock (PUT /ctrl/clock).
 * All values are interpreted as UTC by the controller.
 */
export function setControllerClock(
  year: number, month: number, day: number,
  hour: number, min: number, sec: number,
): { path: string; body: string; method: 'PUT' } {
  return {
    path: buildPath(CTRL.setControllerClock.rws1 as PathSpec),
    body: `sys-clock-year=${year}&sys-clock-month=${month}&sys-clock-day=${day}&sys-clock-hour=${hour}&sys-clock-min=${min}&sys-clock-sec=${sec}`,
    method: 'PUT',
  };
}

// ─── Event log ───────────────────────────────────────────────────────────────

/**
 * Path to read event log messages.
 * Domain 0 = common controller log (up to 1000 entries, most useful).
 * @param domain  - Log domain number; default 0
 * @param lang    - Language for message text; default 'en'
 */
export function elogMessages(domain = 0, lang = 'en'): string {
  return `${buildPath(CFG_ELOG_DIPC.getEventLog.rws1 as PathSpec, { domain })}?lang=${encodeURIComponent(lang)}`;
}

/** Path + body to clear all messages in a specific elog domain. */
export function clearElogDomain(domain = 0): { path: string; body: string } {
  return { path: buildPath(CFG_ELOG_DIPC.clearEventLog.rws1 as PathSpec, { domain }), body: '' };
}

/** Path + body to clear ALL elog messages across all domains. */
export function clearAllElogs(): { path: string; body: string } {
  return { path: buildPath(CFG_ELOG_DIPC.clearAllEventLogs.rws1 as PathSpec), body: '' };
}

// ─── File system ─────────────────────────────────────────────────────────────

/**
 * Path for GET (download file or list directory) and PUT (upload file).
 * Use '$HOME/' prefix to target the controller home directory.
 *
 * Each segment is percent-encoded so names with spaces, '#', '%', etc. survive
 * URL parsing. The '$' of IRC5 volume roots ($HOME, $TEMP, …) stays literal -
 * the controller rejects '%24'.
 */
export function fileServicePath(remotePath: string): string {
  const normalised = remotePath.replace(/^\//, '');
  const encoded = normalised
    .split('/')
    .map(seg => seg.startsWith('$') ? `$${encodeURIComponent(seg.slice(1))}` : encodeURIComponent(seg))
    .join('/');
  return `/fileservice/${encoded}`;
}

/** DELETE path to remove a file from the controller filesystem. */
export function deleteFile(remotePath: string): string {
  return fileServicePath(remotePath);
}

/**
 * Path to create a new directory on the controller filesystem.
 * POST to this path with body 'fs-action=create&fs-newname={dirName}'.
 * @param parentPath - Parent directory path, e.g. '$HOME'
 */
export function createDirectory(parentPath: string): { path: string } {
  return { path: fileServicePath(parentPath) };
}

/** Directory portion of a controller path (`$HOME/Backup/a.mod` -> `$HOME/Backup`),
 *  normalised without a leading slash. Treats both `/` and `\` as separators (to
 *  match the basename extraction below). A bare filename yields ''. */
function dirOf(remotePath: string): string {
  const norm = remotePath.replace(/^\//, '');
  const idx = Math.max(norm.lastIndexOf('/'), norm.lastIndexOf('\\'));
  return idx === -1 ? '' : norm.slice(0, idx);
}

/**
 * Path to copy a file on the controller filesystem.
 * POST to this path with body 'fs-action=copy&fs-newname={filename}'.
 *
 * RWS 1.0 fileservice copy operates *within the source's directory only*:
 * fs-newname must be a bare filename, not a path. So `destPath` must name a file
 * in the SAME directory as the source. A destination in a different directory
 * cannot be honoured by this endpoint - rather than silently copying next to the
 * source (which the old basename-only behaviour did), a cross-directory
 * destination throws INVALID_ARGUMENT. To copy across directories, copy within
 * the source dir then move, or upload to the new path directly.
 *
 * @param sourcePath - Source file path, e.g. '$HOME/Source.mod'
 * @param destPath   - Destination file, e.g. '$HOME/Copy.mod' or a bare
 *                     'Copy.mod'. Must resolve to the source's directory.
 */
export function copyFile(sourcePath: string, destPath: string): { path: string; body: string } {
  const destDir = dirOf(destPath);
  // '' means the caller gave a bare filename => implicitly the source directory.
  if (destDir !== '' && destDir !== dirOf(sourcePath)) {
    throw new RwsError(
      `copyFile: RWS 1.0 can only copy within the source directory. Source dir '${dirOf(sourcePath)}' ` +
      `!= destination dir '${destDir}'. Pass a same-directory destination, or copy-then-move.`,
      'INVALID_ARGUMENT',
    );
  }
  const destBasename = destPath.replace(/^.*[\\/]/, '');
  return {
    path: fileServicePath(sourcePath),
    body: `fs-action=copy&fs-newname=${encodeURIComponent(destBasename)}`,
  };
}

/**
 * Path + body to rename a file in place. RWS 1.0 renames via a POST to the file's
 * fileservice path with `fs-action=rename` and a bare-filename `fs-newname` (the
 * same in-directory form as copy). Live-verified on IRC5 RW6.16 (2026-08-11): 204.
 * @param sourcePath - Existing file path, e.g. '$HOME/A.mod'.
 * @param newName    - New bare filename in the same directory (a directory
 *                     component is stripped).
 */
export function renameFile(sourcePath: string, newName: string): { path: string; body: string } {
  const bare = newName.replace(/^.*[\\/]/, '');
  return {
    path: fileServicePath(sourcePath),
    body: `fs-action=rename&fs-newname=${encodeURIComponent(bare)}`,
  };
}

// ─── Mastership ───────────────────────────────────────────────────────────────

/**
 * Path + body to request mastership on a domain.
 * Must be released after use. Domains: 'cfg' | 'motion' | 'rapid'.
 */
export function requestMastership(domain: 'cfg' | 'motion' | 'rapid'): { path: string; body: string } {
  return { path: buildPath(SYSTEM_MASTERSHIP.requestMastership.rws1 as PathSpec, { domain }), body: '' };
}

/** Path + body to release mastership on a domain. */
export function releaseMastership(domain: 'cfg' | 'motion' | 'rapid'): { path: string; body: string } {
  return { path: buildPath(SYSTEM_MASTERSHIP.releaseMastership.rws1 as PathSpec, { domain }), body: '' };
}

// ─── I/O ─────────────────────────────────────────────────────────────────────

/**
 * Build the signal path segment from optional network/device/name.
 * If network and device are empty, the signal is a virtual flat signal (no prefix).
 */
function signalPath(network: string, device: string, name: string): string {
  if (network && device) {
    return buildPath(IO.readSignal.rws1 as PathSpec, { network, device, name });
  }
  return `/rw/iosystem/signals/${encodeURIComponent(name)}`;
}

/**
 * Path + body to search signals by criteria on RWS 1.0. Uses the query-action
 * form `POST /rw/iosystem/signals?action=signal-search`; criteria AND-compose and
 * `name` is a substring match, same semantics as RWS 2.0. Live-verified on IRC5
 * RW6.16 (2026-08-11): returns the same `ios-signal-li` list as listAllSignals.
 */
export function searchSignals(criteria: { name?: string; device?: string; network?: string; category?: string; type?: string }): { path: string; body: string } {
  const parts: string[] = [];
  if (criteria.name)     { parts.push(`name=${encodeURIComponent(criteria.name)}`); }
  if (criteria.device)   { parts.push(`device=${encodeURIComponent(criteria.device)}`); }
  if (criteria.network)  { parts.push(`network=${encodeURIComponent(criteria.network)}`); }
  if (criteria.category) { parts.push(`category=${encodeURIComponent(criteria.category)}`); }
  if (criteria.type)     { parts.push(`type=${encodeURIComponent(criteria.type)}`); }
  return { path: buildPath(IO.searchSignals.rws1 as PathSpec), body: parts.join('&') };
}

/**
 * Path to list all I/O signals (paginated).
 * @param start  - Starting index (default 0)
 * @param limit  - Max results per page (default 100)
 */
export function allSignals(start = 0, limit = 100): string {
  return `${buildPath(IO.listAllSignals.rws1 as PathSpec)}?start=${start}&limit=${limit}`;
}

/** Path to list all configured I/O networks */
export function networks(): string {
  return buildPath(IO.listNetworks.rws1 as PathSpec);
}

/**
 * Path to list all devices on a network.
 * @param network - Network name, e.g. 'Local'
 */
export function devices(network: string): string {
  return `${buildPath(IO.listDevices.rws1 as PathSpec)}?network=${encodeURIComponent(network)}`;
}

/**
 * Path to read a digital/analog I/O signal value.
 *
 * @param network - I/O network name, e.g. 'Local'. Pass '' for virtual/flat signals.
 * @param device  - I/O device name, e.g. 'DRV_1'. Pass '' for virtual/flat signals.
 * @param name    - Signal name, e.g. 'DI_1'
 */
export function signal(network: string, device: string, name: string): string {
  return signalPath(network, device, name);
}

/**
 * Path to write a digital/analog I/O signal value.
 * The body with lvalue={value} is supplied by the caller (RwsClient.writeSignal).
 *
 * @param network - I/O network name. Pass '' for virtual/flat signals.
 * @param device  - I/O device name. Pass '' for virtual/flat signals.
 * @param name    - Signal name
 */
export function setSignal(network: string, device: string, name: string): { path: string } {
  return {
    path: `${signalPath(network, device, name)}?action=set`,
  };
}

// ─── Subscriptions ───────────────────────────────────────────────────────────

/** Path to create a new WebSocket subscription (POST /subscription) */
export function subscriptions(): string {
  return buildPath(FILES_VISION.createSubscription.rws1 as PathSpec);
}
