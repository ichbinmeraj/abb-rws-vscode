// abb-rws-client - shared type definitions
// Used by BOTH protocol clients: RwsClient (RWS 1.0 / IRC5 / RW6) and
// RwsClient2 (RWS 2.0 / OmniCore / RW7). See src/index.ts for the public surface.

export type ControllerState =
  | 'init'
  | 'motoroff'
  | 'motoron'
  | 'guardstop'
  | 'emergencystop'
  | 'emergencystopreset'
  | 'sysfail';

export type OperationMode = 'AUTO' | 'MANR' | 'MANF';
export type ExecutionState = 'running' | 'stopped';

/** Full execution state including current cycle mode. */
export interface ExecutionInfo {
  state: ExecutionState;
  /** Current cycle mode: 'once' | 'forever' | 'asis' | 'oncedone' */
  cycle: string;
}

export interface JointTarget {
  rax_1: number;
  rax_2: number;
  rax_3: number;
  rax_4: number;
  rax_5: number;
  rax_6: number;
}

export interface RobTarget {
  x: number;
  y: number;
  z: number;
  q1: number;
  q2: number;
  q3: number;
  q4: number;
}

export interface Signal {
  name: string;
  value: string;
  type: 'DI' | 'DO' | 'AI' | 'AO' | 'GI' | 'GO';
  lvalue: string;
}

export interface RapidTask {
  name: string;
  type: string;
  taskstate: string;
  excstate: ExecutionState;
  active: boolean;
  motiontask: boolean;
}

/** Extended RobTarget that includes robot configuration flags returned by /cartesian */
export interface CartesianFull extends RobTarget {
  /** Shoulder configuration: 0 = front, -1 = back */
  j1: number;
  /** Elbow configuration: -1 = down, 1 = up */
  j4: number;
  /** Wrist configuration: -1 = flip, 1 = no flip */
  j6: number;
  /** External axis configuration */
  jx: number;
}

export interface IoNetwork {
  name: string;
  /** Physical state: 'running' | 'stopped' */
  pstate: string;
  /** Logical state: 'started' | 'stopped' */
  lstate: string;
}

export interface IoDevice {
  name: string;
  network: string;
  lstate: string;
  pstate: string;
  address: string;
}

export interface SystemInfo {
  /** Controller/system name */
  name: string;
  /** RobotWare version string, e.g. '6.13.0164' */
  rwVersion: string;
  /** System GUID */
  sysid: string;
  /** Timestamp when RobotWare started */
  startTime: string;
  /** Licensed RobotWare options */
  options: string[];
}

export interface ControllerIdentity {
  /** Controller name */
  name: string;
  /** Controller ID */
  id: string;
  /** 'Real Controller' | 'Virtual Controller' */
  type: string;
  /** MAC address */
  mac: string;
}

/**
 * One substituted argument of an event-log message. The controller stores the
 * message text as a template and supplies the values separately, so "The speed
 * has been adjusted to 100% by Default User" arrives as a title plus
 * `[{type:'long', value:'100'}, {type:'string', value:'Default User'}]`.
 */
export interface ElogArg {
  /** Controller-declared type, e.g. 'long', 'string', 'float'. */
  type: string;
  value: string;
}

export interface ElogMessage {
  /** Sequence number */
  seqnum: number;
  /** Event code, e.g. 10126 */
  code: number;
  /** 1 = info, 2 = warning, 3 = error */
  msgtype: number;
  /** Timestamp string from controller */
  timestamp: string;
  /** Source name (subsystem that generated the event) */
  srcName: string;
  title: string;
  desc: string;
  causes: string;
  consequences: string;
  actions: string;
  /**
   * Substituted values for this message, in order. Empty when the message
   * takes none. Both protocols carry them; they were never read until 2026-08.
   */
  args: ElogArg[];
}

/**
 * A controller status code translated by the controller's own dictionary
 * (`GET /rw/retcode?code=N`). Available on every generation.
 */
export interface ReturnCodeInfo {
  code: number;
  /** ABB's symbolic name, e.g. 'SYS_CTRL_E_NO_SUCH_SYMBOL'. */
  name: string;
  /** e.g. 'Error', 'Warning'. */
  severity: string;
  description: string;
}

/** Controller clock date/time. */
export interface ControllerClock {
  /** Format: 'YYYY-MM-DD T HH:MM:SS' */
  datetime: string;
}

/** Active RAPID UI instruction (e.g. TPReadNum, TPReadFK waiting for input). */
export interface UiInstruction {
  /** Instruction name, e.g. 'TPReadNum', 'TPReadFK' */
  instr: string;
  /** Event type: 'SEND' | 'POST' | 'ABORT' */
  event: string;
  /** Stack URL - used as {stackurl} when setting a parameter value */
  stack: string;
  /** Execution level: 'NORMAL' | 'TRAP' | ... */
  execlv: string;
  /** Message text displayed on FlexPendant */
  msg: string;
}

/** A RAPID symbol found by search (abbreviated properties). */
export interface RapidSymbolInfo {
  /** Full symbol path, e.g. 'RAPID/T_ROB1/user/reg1' */
  symburl: string;
  name: string;
  /** Symbol type: 'var' | 'per' | 'con' | 'fun' | 'prc' | etc. */
  symtyp: string;
  /** Data type name, e.g. 'num', 'string', 'bool', 'robtarget' */
  dattyp: string;
  /** Number of array dimensions (0 = scalar) */
  ndim: number;
  local: boolean;
  ro: boolean;
  taskvar: boolean;
}

/** Parameters for RAPID symbol search. */
export interface RapidSymbolSearchParams {
  /** Task name; required */
  task: string;
  /** Search scope: 'block' | 'scope' | 'stack' */
  view?: 'block' | 'scope' | 'stack';
  /** Variable filter: 'rw' | 'ro' | 'loop' | 'any' */
  vartyp?: string;
  /** Symbol type filter: 'var' | 'per' | 'con' | 'fun' | 'prc' | 'mod' | 'tsk' | 'any' */
  symtyp?: string;
  /** Data type filter, e.g. 'num', 'bool', 'robtarget' */
  dattyp?: string;
  /** Regex pattern for symbol name matching */
  regexp?: string;
  /** Whether to search recursively; default true */
  recursive?: boolean;
  /** URL of module/routine to search within */
  blockurl?: string;
}

/** Controller restart mode. */
/**
 * Controller restart modes. `restart` (warm), `istart` (re-install the system),
 * `pstart` (restart and delete the program), `bstart` (restart from the last
 * backup) are accepted on both protocol generations.
 *
 * `shutdown` and `xstart` are RWS 2.0 only: the RobotWare 7/8 `/ctrl/restart`
 * form advertises all six, while the RWS 1.0 panel form lists only the first
 * four (live-verified 2026-08 by reading each controller's own OPTIONS form).
 */
export type RestartMode = 'restart' | 'istart' | 'pstart' | 'bstart' | 'shutdown' | 'xstart';

export interface FileEntry {
  name: string;
  type: 'file' | 'dir';
  /** File size in bytes (files only) */
  size?: number;
  /** Creation timestamp from controller */
  created?: string;
  /** Last-modified timestamp from controller */
  modified?: string;
  /** Whether the file is read-only (files only) */
  readonly?: boolean;
}

export type MastershipDomain = 'cfg' | 'motion' | 'rapid';

/**
 * Collision detection state returned by GET /rw/panel/coldetstate.
 * INIT = no collision detected (normal operation).
 * TRIGGERED = collision detected, not yet acknowledged.
 * CONFIRMED = collision confirmed.
 * TRIGGERED_ACK = collision acknowledged.
 */
export type CollisionDetectionState = 'INIT' | 'TRIGGERED' | 'CONFIRMED' | 'TRIGGERED_ACK';

/** Execution cycle mode returned/set by /rw/rapid/execution */
export type ExecutionCycle = 'once' | 'forever' | 'asis';

/**
 * RAPID symbol properties returned by GET /rw/rapid/symbol/properties/RAPID/{task}/{module}/{symbol}.
 * symtyp: 'var' | 'per' | 'con' | 'par' | 'fun' | 'prc' | 'mod' | 'tsk' | 'any' | 'udef' | 'atm' | 'rec' | 'ali' | 'rcp'
 */
export interface RapidSymbolProperties {
  /** Full symbol URL path */
  symburl: string;
  /** Symbol type: var/per/con/par/fun/prc/mod/tsk/any/udef/atm/rec/ali/rcp */
  symtyp: string;
  /** Whether the symbol has a name */
  named: boolean;
  /** Data type name, e.g. 'num', 'string', 'bool', 'robtarget' */
  dattyp: string;
  /** Number of array dimensions (0 = scalar) */
  ndim: number;
  /** Dimension sizes as a string, e.g. '[3]' for 3-element array */
  dim: string;
  /** Whether the symbol is heap-allocated */
  heap: boolean;
  /** Whether the symbol definition is complete (linked) */
  linked: boolean;
  /** Whether the symbol is module-local (not global) */
  local: boolean;
  /** Whether the persistent is read-only */
  ro: boolean;
  /** Whether the symbol is task-global (taskvar) */
  taskvar: boolean;
  /** Storage type: 'local' | 'task' | 'global' */
  storage: string;
  /** URL reference to the type symbol */
  typurl: string;
}

export interface RwsClientOptions {
  /** IP address or hostname, e.g. '192.168.125.1' or '127.0.0.1' for RobotStudio */
  host: string;
  /** HTTP port; default 80 */
  port?: number;
  /** Default 'Admin' */
  username?: string;
  /** Default 'robotics' */
  password?: string;
  /** Minimum ms between requests; default 55ms (enforces <20 req/sec RWS rate limit) */
  requestIntervalMs?: number;
  /** Request timeout in ms; default 5000 */
  timeout?: number;
  /** Saved -http-session- cookie value to reuse an existing controller session slot */
  sessionCookie?: string;
}

export type SubscriptionResource =
  | 'execution'
  | 'controllerstate'
  | 'operationmode'
  | 'speedratio'
  | 'coldetstate'
  | 'uiinstr'
  | { type: 'signal'; name: string }
  | { type: 'persvar'; name: string }
  | { type: 'taskchange'; task: string }
  | { type: 'execycle' }
  | { type: 'elog'; domain: number };

/**
 * Strip a leading `RAPID/` from a symbol path.
 *
 * The two protocols disagree on the shape of a persistent-variable subscription:
 * RWS 1.0 wants `/rw/rapid/symbol/data/RAPID/{task}/{module}/{sym};value` and
 * RWS 2.0 wants `/rw/rapid/symbol/RAPID/{task}/{module}/{sym}/data;value`, and
 * each rejects the other's shape. Both builders normalize through this helper so
 * one `{ type: 'persvar', name }` works on either adapter, with or without the
 * prefix. Live-verified 2026-08 on RW6.16, RW7.21 and RW8.1.1.
 */
export function stripRapidDomain(name: string): string {
  return name.replace(/^\/?RAPID\//i, '');
}

export interface SubscriptionEvent {
  resource: string;
  value: string;
  timestamp: Date;
}

/**
 * How healthy the connection to a controller currently is:
 * - 'live'          - WebSocket subscriptions streaming; polling at slow cadence
 * - 'polling'       - no WebSocket (unavailable or lost); fast polling covers state
 * - 'reconnecting'  - a connect attempt is in flight
 * - 'stale'         - 1-2 consecutive polls failed; data may be outdated
 * - 'disconnected'  - not connected (never, by user, or after repeated failures)
 * The accompanying `qualityReason` on RobotState says why in human terms.
 */
export type ConnectionQuality = 'live' | 'polling' | 'reconnecting' | 'stale' | 'disconnected';

export type RwsErrorCode =
  | 'SESSION_EXPIRED'
  | 'AUTH_FAILED'          // credential/handshake failure ONLY - other 403s get the codes below
  | 'MOTORS_OFF'
  | 'MODULE_NOT_FOUND'
  | 'RESOURCE_NOT_FOUND'   // 404-family: signal/file/symbol/path does not exist
  | 'MASTERSHIP_REQUIRED'  // write needs mastership, or another client holds it
  | 'GRANT_DENIED'         // controller rejected the operation (RMMP not granted / UAS grant missing)
  | 'WRONG_MODE'           // operation not allowed in the current controller state or op-mode
  | 'UNSUPPORTED_OPERATION' // this protocol generation / controller does not have the operation
  | 'INVALID_ARGUMENT'     // caller passed a value the controller cannot accept; nothing was sent
  | 'NOT_CONNECTED'        // connect() has not run (or the manager has no adapter yet)
  | 'RATE_LIMITED'
  | 'CONTROLLER_BUSY'
  | 'NETWORK_ERROR'
  | 'PARSE_ERROR'
  | 'PROTOCOL_DETECT_FAILED'
  | 'UNKNOWN';

/**
 * Typed error thrown by all abb-rws-client public methods.
 * Always check `code` for programmatic error handling.
 */
export class RwsError extends Error {
  readonly code: RwsErrorCode;
  readonly httpStatus?: number;
  readonly rwsDetail?: string;
  /** Controller-native status code from the error body (e.g. -1073445862), when present. */
  readonly controllerCode?: number;
  /** Controller-native message from the error body, cleaned of build-path noise. */
  readonly controllerMsg?: string;

  constructor(
    message: string, code: RwsErrorCode, httpStatus?: number, rwsDetail?: string,
    controllerCode?: number, controllerMsg?: string,
  ) {
    super(message);
    this.name = 'RwsError';
    this.code = code;
    this.httpStatus = httpStatus;
    this.rwsDetail = rwsDetail;
    this.controllerCode = controllerCode;
    this.controllerMsg = controllerMsg;
    // Restore prototype chain so instanceof checks work correctly when targeting ES2022
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

// ─── Internal types (not re-exported from index.ts) ─────────────────────────

/** @internal Parsed fields from a WWW-Authenticate: Digest ... header (RFC 2617) */
export interface DigestChallenge {
  realm: string;
  nonce: string;
  opaque?: string;
  /** 'auth' | 'auth-int' - if absent, use RFC 2069 compat mode */
  qop?: string;
  /** Hash algorithm - typically 'MD5' (default) */
  algorithm?: string;
  stale?: boolean;
  domain?: string;
}

/** @internal Return type for all HttpSession HTTP methods */
export interface HttpResponse {
  status: number;
  body: string;
  headers: Headers;
}

/**
 * Read the substituted arguments out of one parsed event-log message.
 *
 * The two representations carry them differently and neither is documented:
 *   hal+json / ?json=1 : "argv":[{"type":"long","value":100}, ...]
 *   XHTML              : <span class="arg1" type="long">100</span> ...
 * Handles both, on both protocol generations. Returns [] when the message
 * takes no arguments, which is the common case.
 */
export function decodeElogArgs(fields: Record<string, unknown>): ElogArg[] {
  const raw = fields['argv'];
  // RWS 1.0's ?json=1 path hands over the parsed array; the hal+json parser
  // keeps it as a JSON string. Accept either.
  const list: unknown = typeof raw === 'string' && raw
    ? ((): unknown => { try { return JSON.parse(raw); } catch { return undefined; } })()
    : raw;
  if (Array.isArray(list)) {
    return (list as Array<{ type?: unknown; value?: unknown }>).map(a => ({
      type: String(a?.type ?? ''),
      value: String(a?.value ?? ''),
    }));
  }
  const count = Number(fields['argc'] ?? 0);
  if (!Number.isFinite(count) || count <= 0) { return []; }
  const out: ElogArg[] = [];
  for (let i = 1; i <= count; i++) {
    const v = fields[`arg${i}`];
    if (v === undefined) { continue; }
    out.push({ type: '', value: String(v) });
  }
  return out;
}

// ─── Endpoint-completion additions (2026-08-09) ──────────────────────────────
// Every shape below was read off a controller's own OPTIONS form, not the
// specification. See docs/tasks/endpoint-completion.md for the evidence.

/**
 * What `RwsClient2.subscribe()` returns: call it to unsubscribe, exactly as
 * before, but it also carries the group's resource path so the group can be
 * edited in place via `updateSubscriptionGroup` / `unsubscribeResource`.
 *
 * `groupPath` is read live rather than snapshotted - a reconnect mints a new
 * group - and is `''` while no group is currently held.
 */
export type SubscriptionHandle = (() => Promise<void>) & {
  readonly groupPath: string;
};

/**
 * Criteria for POST /rw/iosystem/signals/signal-search-ex.
 *
 * The OPTIONS form (live-read 2026-08-09 on RW7.21 and RW8.1.1) advertises every
 * field twice - `name`/`name2`, `device`/`device2`, ... - so the controller
 * takes up to TWO criteria sets. The second set NARROWS the first (logical AND),
 * it does not union with it. Live-verified 2026-08-09 on RW8.1.1:
 *   type=DI            -> 33 signals
 *   type=DO            -> 39 signals
 *   type=DI & type2=DI -> 33 signals   (intersection with itself)
 *   type=DI & type2=DO ->  0 signals   (nothing is both)
 * An empty body returns everything. `name` matches literally - there is no glob
 * support, and `name=*` returns 0 rather than all.
 */
export interface SignalSearchExCriteria {
  name?: string;
  device?: string;
  network?: string;
  category?: string;
  /** Maps to the form's `category-pon` field. */
  categoryPon?: string;
  type?: string;
  invert?: boolean;
  blocked?: boolean;
}

/**
 * Request for POST /rw/cfg/validate-instances.
 *
 * This validates CFG instances that ALREADY EXIST; it is not a dry run for
 * instances you are about to create. Live-verified 2026-08-09 on RW8.1.1: an
 * existing signal name (`ASI_C1_PIN8_DI`) answers 204, while every synthetic
 * name and every `-Name "..." -SignalType "..."` instance body answers 200 with
 * "Instance name not found, or the type is not named".
 */
export interface CfgValidateRequest {
  /**
   * The form's `operation` field - numeric, NOT a verb. The controller accepts
   * only 0 and 1 and rejects every other value (including 'add', 'update',
   * 'validate' and any integer outside 0..1) with
   * "Invalid operation parameter value". Live-verified 2026-08-09.
   */
  operation: 0 | 1;
  /** The form's `cfgdomain` field, e.g. 'EIO', 'MOC', 'SYS'. */
  domain: string;
  /** The form's `cfgtype` field, e.g. 'EIO_SIGNAL'. */
  type: string;
  /** Names of existing instances; sent as `instances`, `instancescount` derived. */
  instances: string[];
}

/**
 * ModPos - POST /rw/rapid/tasks/{task}/modules/{module}/modify-position.
 * Form fields live-read 2026-08-09 on RW7.21.
 */
export interface ModifyPositionOptions {
  startRow: number;
  startCol: number;
  endRow?: number;
  endCol?: number;
  /** Form field `checklimit`. */
  checkLimit?: boolean;
  /** Form field `checkdeactaxes`. */
  checkDeactAxes?: boolean;
  /** Form field `allowdeact`. */
  allowDeact?: boolean;
  /** Form field `text`. */
  text?: string;
}

/** A saved-diagnostics record from GET /ctrl/diagnostics. */
export interface DiagnosticsInfo {
  /** True when the controller has no diagnostics saved yet (it answers 400). */
  empty: boolean;
  entries: Array<Record<string, string>>;
}

/**
 * POST /users/register - form fields live-read 2026-08-09
 * (`application`, `username`, `location`, `ulocale`).
 */
export interface UserRegistration {
  application: string;
  username: string;
  location: string;
  /** Form field `ulocale`. */
  locale?: string;
}
